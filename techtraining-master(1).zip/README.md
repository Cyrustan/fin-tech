# techtraining

This repository includes code that was used as part of a 4 week training camp in software development. The following topics were covered furing the training: 
- Week 1: Introduction to the Software Development Life Cycle (SDLC)
- Week 2: Introduction to Relational Databases
- Week 3: REST services with DropWizard
- Week 4: Front-end Development (HTML/CSS/JS)

The training was delivered online and attended by students interested in starting careers in software development.
