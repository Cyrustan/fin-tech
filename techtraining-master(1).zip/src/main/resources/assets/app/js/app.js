(function () {
    var app = angular.module('my_app', []);
    app.controller('MainController', ['$scope', '$http', function ($scope, $http) {
        $scope.investorName = '';
        $scope.getInvestor = function () {
            if ($scope.investorName === '') {
                alert('Please insert an investor name');
                return;
            }
            $http({
                method: 'GET',
                url: '/investor/' + $scope.investorName
            }).then(
                function success(response) {
                    $scope.investorID = response.data.id;
                    if (response.data.address === null) {
                        $scope.investorAddress = 'Address not available!';
                    } else {
                        $scope.investorAddress = response.data.address;
                    }
                    $scope.investorSSN = response.data.ssn;
                },
                function failure(response) {
                    $scope.investorID = '';
                    $scope.investorAddress = '';
                    $scope.investorSSN = '';
                    alert('failed to get investor details!');
                }
            )
        };

        $scope.update = function () {
            var investor = {
                id: $scope.investorID,
                name: $scope.investorName,
                address: $scope.investorAddress,
                ssn: $scope.investorSSN
            };
            $http({
                method: 'POST',
                url: '/investor/update',
                data: investor
            }).then(function success(response) {
                alert('The investor data has been updated!');
            }, function failure(response) {
                alert('Was not able to update the investor!');
            });
        };
        $scope.getStocks = function () {
            $http({
                method: 'GET',
                url: '/stock'
            }).then(
                function success(response) {
                    var tbody = window.document.getElementById("tbody-result");
                    if (response.data.length > 0) {
                        var data = response.data
                        var str = "";

                        for (i in data) {
                            str += "<tr>" +
                                "<td align='center'>" + data[i].id + "</td>" +
                                "<td align='center'>" + data[i].name + "</td>" +
                                "<td align='center'>" + data[i].currentprice + "</td>" +
                                "<td align='center'>" + data[i].previouclosingprice + "</td>" +
                                "</tr>";
                        }
                        tbody.innerHTML = str;
                    } else {
                        var str = "<td align='center'>the database haven't stock data Temporarily </td>";
                        tbody.innerHTML = str;
                    }

                },
                function failure(response) {
                    alert('failed to get stock details!');
                }
            )
        };

        $scope.add = function () {
            if ($scope.stockName === '') {
                alert('Please insert an stock name');
                return;
            }
            var stock = {
                name: $scope.stockName,
                currentprice: $scope.stockcurrentPrice,
                previouclosingprice: $scope.stockpreviouClosingPrice
            };
            debugger
            $http({
                method: 'POST',
                url: '/stock/add',
                data: stock
            }).then(function success(response) {
                alert('The stock data has been added!');
                $scope.getStocks()
            }, function failure(response) {
                alert('Was not able to add the stock!');
            });
        }
        ;

    }]);
})();