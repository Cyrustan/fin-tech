package db;

import javax.persistence.*;

/**
 * Created by Moe on 2/10/18.
 */
@Entity
@Table(name = "STOCKS", schema = "FinTech_Training")
public class Stock {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "STOCK_ID",unique = true,nullable=false)
    private int id;
    @Column(name = "NAME")
    private String name;
    @Column(name = "CURRENTPRICE")
    private String currentprice;
    @Column(name = "PREVIOUCLOSINGPRICE")
    private String previouclosingprice;

    public Stock() {
        // default no-arg constructor for hibernate
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }



    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrentprice() {
        return currentprice;
    }

    public void setCurrentprice(String currentprice) {
        this.currentprice = currentprice;
    }

    public String getPreviouclosingprice() {
        return previouclosingprice;
    }

    public void setPreviouclosingprice(String previouclosingprice) {
        this.previouclosingprice = previouclosingprice;
    }
}
