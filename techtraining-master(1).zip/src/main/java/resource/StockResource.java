package resource;

import db.Stock;
import db.StockDAO;
import io.dropwizard.hibernate.UnitOfWork;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Created by Moe on 2/10/18.
 */
@Path("stock")
@Produces(MediaType.APPLICATION_JSON)
public class StockResource {

    private StockDAO stockDAO;

    public StockResource(StockDAO stockDAO) {
        this.stockDAO = stockDAO;
    }

    @GET
    @UnitOfWork
    public Response getStocks() {
        return Response.ok(stockDAO.getStocks()).build();
    }

    @GET
    @UnitOfWork
    @Path("/{name}")
    public Response getStock(@PathParam("name") String name) {
        return Response.ok(stockDAO.getStock(name)).build();
    }


    @POST
    @Path("/update")
    @UnitOfWork
    public Response updateStock(Stock stock) {
        stockDAO.updateStock(stock);
        return Response.ok().build();
    }


    @POST
    @Path("/add")
    @UnitOfWork
    public Response addStock(Stock stock) {
        stockDAO.addStock(stock);
        return Response.ok().build();
    }

    @DELETE
    @Path("/delete/{id}")
    @UnitOfWork
    public Response removeStock(@PathParam("id") int id) {
        stockDAO.removeStock(id);
        return Response.ok().build();
    }
}