package db;

import io.dropwizard.hibernate.AbstractDAO;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import java.util.List;

/**
 * Created by Moe on 2/10/18.
 */
public class StockDAO extends AbstractDAO<Stock> {

    public StockDAO(SessionFactory sessionFactory) {
        super(sessionFactory);
    }

    public List<Stock> getStocks() {
        return currentSession().createCriteria(Stock.class).list();
    }

    public Stock getStock(String name) {
        Criteria cr = criteria().add(Restrictions.eq("name", name));
        return (Stock) cr.list().get(0);
    }

    public void addStock(Stock stock) {
        persist(stock);
    }

    public void removeStock(int stockId) {
        Stock stockToBeRemoved = get(stockId);
        currentSession().delete(stockToBeRemoved);
    }

    public void updateStock(Stock stock) {
        Stock sto = get(stock.getId());
        sto.setCurrentprice(stock.getCurrentprice());
        sto.setName(stock.getName());
        sto.setPreviouclosingprice(stock.getPreviouclosingprice());
        persist(sto);
    }

}
